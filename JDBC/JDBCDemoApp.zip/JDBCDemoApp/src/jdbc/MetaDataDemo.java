package jdbc;

public class MetaDataDemo {

}
