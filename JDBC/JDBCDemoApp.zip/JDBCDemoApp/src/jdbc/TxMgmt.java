package jdbc;

public class TxMgmt {

}
